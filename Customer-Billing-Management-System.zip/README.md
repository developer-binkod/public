# Travel Agency Software Solution
CRM, Ticketing, Billing, Accounts &amp; Payroll software for Retail &amp; Business Travel Agencies.

# The application consists of:
<ul>
    <li>CRM - Customer Management, Billing.</li>
    <li>Ticketing - Amadeus, Gallelio, Sabre</li>
    <li>Accounting</li>
    <li>Custom Services Billing</li>
    <li>Accounting</li>
    <li>Reporting</li>
    <li>Banking</li>
</ul>

# NOTES
The application is currently under development, and we are looking for sponsors who can sponsor this application in all platforms in order to be launched into the market for retail travel agencies and also business travel agencies. We are putting a lot of effort in order to put all aspects of business into it. Since we are working as voluntarily in this application, progress can be a little slow. The application is currently using all open source technologies, starting from templates, plugins, nuget packages and others.

# MIT LICENSE
A short and simple permissive license with conditions only requiring preservation of copyright and license notices. Licensed works, modifications, and larger works may be distributed under different terms and without source code.

# DEMO
The application will be hosted very soon, and will be coming to live for a demo
username:
password: